param([string]$Configuration = 'Release', [int]$Parallel = 4, [switch]$PrepareSourceOnly)
$ErrorActionPreference = 'Stop'
if ($Configuration -notin @('Debug', 'Release')) { throw 'Configuration must be Debug or Release' }
$workspace = Split-Path -Parent $PSScriptRoot
$version = '6.12.0'
$archive = Join-Path $workspace "work/dependencies/qtbase-everywhere-src-$version.tar.xz"
$source = Join-Path $workspace "work/dependencies/qtbase-everywhere-src-$version"
$build = Join-Path $workspace "work/qt-build-desktop-$Configuration"
$prefix = Join-Path $workspace "work/qt-static-$Configuration"
$hash = 'a951bd163c7b80fc6b8c88d7668fb56abf91c152373e13c10666763238131307'
New-Item -ItemType Directory -Force -Path (Split-Path $archive), $build | Out-Null
# 공식 소스와 해시 고정, 소스는 LGPL 배포/재링크 자료에도 동일하게 사용
if (!(Test-Path -LiteralPath $archive)) {
    Invoke-WebRequest "https://download.qt.io/official_releases/qt/6.12/$version/submodules/qtbase-everywhere-src-$version.tar.xz" -OutFile $archive
}
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $hash) { throw 'Qt source hash mismatch' }
if (!(Test-Path -LiteralPath (Join-Path $source 'CMakeLists.txt'))) {
    & tar -xf $archive -C (Split-Path $source)
    if ($LASTEXITCODE -ne 0) { throw 'Qt extraction failed' }
}

# 캐시 적중 시에도 공식 소스 해시 검증과 LGPL 고지/재링크 원본 준비
if ($PrepareSourceOnly)
{
    Write-Output "Verified Qt source ready: $source"

    return
}

# 기존 개발자 터미널 또는 설치된 Visual Studio 환경 사용, 고정 사용자 경로 제거
if (!$env:VCToolsInstallDir) {
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
    $installation = & $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
    if (!$installation) { throw 'MSVC build tools not found' }
    $developer = Join-Path $installation 'Common7/Tools/VsDevCmd.bat'
    $variables = & cmd.exe /d /s /c "`"$developer`" -arch=x64 -host_arch=x64 >nul && set"
    foreach ($line in $variables) {
        if ($line -match '^([^=]+)=(.*)$') { [Environment]::SetEnvironmentVariable($Matches[1], $Matches[2], 'Process') }
    }
    $ninja = Join-Path $installation 'Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja'
    $env:PATH = "$ninja;$env:PATH"
}
$env:VSLANG = '1033'
& cmake -S $source -B $build -G Ninja "-DCMAKE_BUILD_TYPE=$Configuration" "-DCMAKE_INSTALL_PREFIX=$prefix" `
    '-DBUILD_SHARED_LIBS=OFF' '-DFEATURE_static_runtime=ON' '-DQT_BUILD_TESTS=OFF' '-DQT_BUILD_EXAMPLES=OFF' `
    '-DQT_BUILD_BENCHMARKS=OFF' '-DINPUT_opengl=desktop' '-DFEATURE_sql=OFF' '-DFEATURE_dbus=OFF' `
    '-DFEATURE_openssl=OFF' '-DFEATURE_ssl=OFF'
if ($LASTEXITCODE -ne 0) { throw 'Qt configuration failed' }
& cmake --build $build --parallel $Parallel
if ($LASTEXITCODE -ne 0) { throw 'Qt build failed' }
& cmake --install $build
if ($LASTEXITCODE -ne 0) { throw 'Qt installation failed' }
Write-Output "Static Qt ready: $prefix"
