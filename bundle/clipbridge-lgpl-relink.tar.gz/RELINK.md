# Qt 정적 링크 배포와 재링크

ClipBridge의 Windows UI는 Qt Core/Gui/Widgets를 LGPLv3 조건으로 정적 링크한다. 일반 실행에는 EXE 하나만 필요하며, 사용자는 아래 자료로 Qt를 수정/교체하고 앱을 다시 링크할 수 있다. 앱의 원본 소스 공개와 별개로 LGPL 권리 행사에 필요한 재링크 자료를 제공한다. LGPL/GPL 원문과 Qt/서드파티 고지를 라이선스 메뉴와 배포 자료에서 확인할 수 있다.

## 재링크 자료

- 해당 EXE 버전의 앱 `.obj`와 `.lib`, 정적 curl 라이브러리
- `CMakeLists.txt`와 `work/dependencies/qtbase-everywhere-src-6.12.0.tar.xz`의 정확한 Qt 소스 아카이브
- Qt 소스 SHA-256: `a951bd163c7b80fc6b8c88d7668fb56abf91c152373e13c10666763238131307`
- LGPL/GPL 및 사용한 라이브러리의 고지, Qt 정적 빌드 절차
- 사용자 설정/토큰/로그/개인 서명 키/PDB는 미포함

## 사용자가 Qt를 교체하는 절차

1. 자료를 새 폴더에 해제, x64 MSVC 개발자 터미널 준비, 배포 빌드와 호환되는 MSVC ABI 사용
2. 제공한 Qt 소스를 해제하고 필요한 변경 적용, 원본 소스/변경 내용은 Qt 배포 조건에 따라 제공
3. 제공한 `scripts/build_qt_static.ps1 -Configuration Release`로 정적 Qt 빌드/설치, 변경한 소스 폴더가 있으면 다시 내려받지 않음, 동일 MSVC/Qt 구성 필요
4. 재링크 자료 폴더에서 `cmake -S . -B rebuilt -A x64 -DCMAKE_PREFIX_PATH=<교체한 Qt 설치 경로>` 실행
5. `cmake --build rebuilt --config Release` 실행, `rebuilt/Release/clipbridge.exe`를 원하는 쓰기 가능한 폴더에서 실행

재링크한 EXE 자체의 실행에는 개발자 서명이나 원본 해시가 필요하지 않다. 공식 업데이트의 서명 검증은 자동 다운로드 파일의 출처 확인용이다. 교체한 Qt를 계속 사용하려면 자동 업데이트를 끄면 된다. 수정된 라이브러리 디버깅에 필요한 역공학을 금지하는 별도 조건은 부과하지 않는다.

Qt 공식 소스: https://download.qt.io/official_releases/qt/6.12/6.12.0/submodules/qtbase-everywhere-src-6.12.0.tar.xz

현재 Linux 패키지는 배포판의 공유 Qt를 사용하므로 시스템 라이브러리 교체 방식으로 동작한다. Windows와 UI/컨트롤러/MIME 변환 소스는 동일하다. GPL 전용 Qt 모듈은 사용하지 않는다.
