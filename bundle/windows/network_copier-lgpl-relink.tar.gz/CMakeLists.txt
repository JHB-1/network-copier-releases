cmake_minimum_required(VERSION 3.25)
project(network_copier_relink LANGUAGES CXX RC)
set(CMAKE_CXX_STANDARD 23)
set(CMAKE_AUTORCC ON)
set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
find_package(Qt6 REQUIRED COMPONENTS Widgets Network ZlibPrivate)
get_target_property(qt_type Qt6::Core TYPE)
if(NOT qt_type STREQUAL "STATIC_LIBRARY")
    message(FATAL_ERROR "Use an LGPL static Qt build with the matching MSVC runtime")
endif()
file(GLOB objects "${CMAKE_CURRENT_SOURCE_DIR}/objects/*.obj")
if(NOT objects)
    message(FATAL_ERROR "Application object files missing")
endif()
qt_add_executable(network_copier ${objects} network_copier.manifest network_copier.rc branding.qrc)

# 원본과 같은 정적 플러그인으로 화면 없는 시작 검증도 유지
qt_import_plugins(network_copier INCLUDE Qt6::QOffscreenIntegrationPlugin)
target_include_directories(network_copier PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}")
set_target_properties(network_copier PROPERTIES WIN32_EXECUTABLE TRUE LINKER_LANGUAGE CXX)
target_link_libraries(network_copier PRIVATE
    "${CMAKE_CURRENT_SOURCE_DIR}/libraries/network_copier_ui.lib"
    "${CMAKE_CURRENT_SOURCE_DIR}/libraries/network_copier_services.lib"
    "${CMAKE_CURRENT_SOURCE_DIR}/libraries/network_copier_clipboard.lib"
    "${CMAKE_CURRENT_SOURCE_DIR}/libraries/network_copier_core.lib"
    "${CMAKE_CURRENT_SOURCE_DIR}/libraries/libcurl.lib"
    Qt6::Widgets Qt6::Network Qt6::ZlibPrivate advapi32 bcrypt crypt32 shell32 ws2_32 secur32 iphlpapi ole32 user32 windowscodecs)
